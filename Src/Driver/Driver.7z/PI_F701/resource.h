//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PI_F701Drv.rc
//
#define IDP_SOCKETS_INIT_FAILED         101
#define IDC_BUTTON_TEST                 1000
#define IDD_DIALOG_PISERVER_ITEM        1001
#define IDC_LIST_PISERVER               1001
#define IDC_BUTTON_ADD                  1002
#define IDC_BUTTON_EDIT                 1003
#define IDC_BUTTON_DELETE               1004
#define IDC_BUTTON_UP                   1005
#define IDC_BUTTON3                     1006
#define IDC_BUTTON_DOWN                 1006
#define IDC_BTN_SQL_TEST                1007
#define IDC_CHK_PI_SERVER               1008
#define IDC_CHK_SQL_SERVER              1009
#define IDC_EDIT_SERVERNAME             9000
#define IDD_DIALOG_CFG                  9000
#define IDC_EDIT_CONNTIMEOUT            9001
#define IDC_EDIT_DATIMEOUT              9002
#define IDC_EDIT_PASSWARD               9005
#define IDC_EDIT_USERNAME               9006
#define IDC_EDIT_PORTNUM                9007
#define IDC_EDIT_PORT                   28006
#define IDC_EDIT_USER                   28008
#define IDC_EDIT_SERVER                 28016
#define IDC_EDIT_DATABASE               28019
#define IDC_EDIT_DATABASE2              28020
#define IDC_EDIT_TABLE                  28020
#define IDC_EDIT_PASSWORD               28021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1002
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           1000
#endif
#endif
